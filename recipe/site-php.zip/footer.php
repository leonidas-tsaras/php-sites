<footer>
        <div id = "footer-wrapper">
            <div>
                <a href="">
                    <img src="./images/logo.png" alt="">
                </a>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
            </div>
            <div>
                <h2>Usefull links</h2>
                <nav>
                    <a href="#">Privacy Policy</a>
                    <a href="#">Contact Us</a>
                    <a href="#">WhatsApp: +30 1234567890</a>
                    <a href="#">Email: info@example.com</a>
                    <a href="#">Tel: +30 1234567890</a>
                </nav>
            </div>
            <div>
                <h2>Follow New Listings</h2>
                <p>Sign up with your email address to receive news and updates.</p>
                <form onsubmit="sendEmail(event)">
                    <input type="email" placeholder="Email address" value = "">
                    <input type="submit" value="Sign up">
                </form>
                <p id = "message"></p>
            </div>
        </div>
    </footer>
