<header>
    <section>
        <div id = "logo">
            <a href=""><img src="images/logo.png" alt=""></a>
        </div>
        <nav>
            <a href = "">Home</a>
            <a href = "recipes">Recipes</a>
            <a href = "desserts">Desserts</a>
            <a href = "price-list">Price list</a>
            <a href = "about">About</a>
            <a href = "contact">Contact</a>
        </nav>
        <div id="burger-icon">☰</div>
    </section>
</header>